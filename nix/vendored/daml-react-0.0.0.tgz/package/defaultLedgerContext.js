"use strict";
// Copyright (c) 2023 Digital Asset (Switzerland) GmbH and/or its affiliates. All rights reserved.
// SPDX-License-Identifier: Apache-2.0
Object.defineProperty(exports, "__esModule", { value: true });
exports.useReload = exports.useStreamFetchByKeys = exports.useStreamFetchByKey = exports.useStreamQueries = exports.useStreamQuery = exports.useFetchByKey = exports.useFetch = exports.useQuery = exports.useLedger = exports.useUser = exports.useParty = exports.DamlLedger = void 0;
var createLedgerContext_1 = require("./createLedgerContext");
/**
 * @internal
 */
var ledgerContext = (0, createLedgerContext_1.createLedgerContext)();
/**
 * Within a `DamlLedger` one can use the hooks provided here.
 *
 * @param props React props and children for this element.
 */
function DamlLedger(props) {
    return ledgerContext.DamlLedger(props);
}
exports.DamlLedger = DamlLedger;
/**
 * React hook to get the party currently connected to the ledger.
 */
function useParty() {
    return ledgerContext.useParty();
}
exports.useParty = useParty;
/**
 * React hook to get the user currently connected to the ledger participant.
 */
function useUser() {
    return ledgerContext.useUser();
}
exports.useUser = useUser;
/**
 * React Hook that returns the Ledger instance to interact with the connected Daml ledger.
 */
function useLedger() {
    return ledgerContext.useLedger();
}
exports.useLedger = useLedger;
function useQuery(template, queryFactory, queryDeps) {
    return ledgerContext.useQuery(template, queryFactory, queryDeps);
}
exports.useQuery = useQuery;
/**
 * React Hook for a lookup by contractId against the `/v1/fetch` endpoint of the JSON API.
 *
 * @typeparam T The contract template type of the query.
 * @typeparam K The contract key type of the query.
 * @typeparam I The template id type.
 *
 * @param template The template of the contract to fetch.
 * @param contractId The contractId to fetch.
 *
 * @return The fetched contract.
 */
function useFetch(template, contractId) {
    return ledgerContext.useFetch(template, contractId);
}
exports.useFetch = useFetch;
/**
 * React Hook for a lookup by key against the `/v1/fetch` endpoint of the JSON API.
 *
 * @typeparam T The contract template type of the query.
 * @typeparam K The contract key type of the query.
 * @typeparam I The template id type.
 *
 * @param template The template of the contracts to fetch.
 * @param keyFactory A function returning the contract key of the contracts to fetch.
 * @param keyDeps Dependencies of this hook (for which the fetch is reexecuted on change).
 *
 * @return The fetched contract.
 */
function useFetchByKey(template, keyFactory, keyDeps) {
    return ledgerContext.useFetchByKey(template, keyFactory, keyDeps);
}
exports.useFetchByKey = useFetchByKey;
/**
 * React Hook to query the ledger, the returned result is updated as the ledger state changes.
 *
 * @deprecated prefer useStreamQueries
 *
 * @typeparam T The contract template type of the query.
 * @typeparam K The contract key type of the query.
 * @typeparam I The template id type.
 *
 * @param template The template of the contracts to match.
 * @param queryFactory A function returning a query. If the query is omitted, all visible contracts of the given template are returned.
 * @param queryDeps The dependencies of the query (for which a change triggers an update of the result).
 * @param closeHandler A callback that will be called if the underlying WebSocket connection fails in an unrecoverable way.
 *
 * @return The matching contracts.
 */
function useStreamQuery(template, queryFactory, queryDeps, closeHandler) {
    return ledgerContext.useStreamQuery(template, queryFactory, queryDeps, closeHandler);
}
exports.useStreamQuery = useStreamQuery;
/**
 * React Hook to query the ledger, the returned result is updated as the ledger state changes.
 *
 * @typeparam T The contract template type of the query.
 * @typeparam K The contract key type of the query.
 * @typeparam I The template id type.
 *
 * @param template The template of the contracts to match.
 * @param queryFactory A function returning an array of queries. If no queryFactory is given, or if the given factory returns an empty array, all visible contracts of the given template are returned. Otherwise, returns a union of all the contracts that match at least one of the given queries.
 * @param queryDeps The dependencies of the query (for which a change triggers an update of the result).
 * @param closeHandler A callback that will be called if the underlying WebSocket connection fails in an unrecoverable way.
 *
 * @return The matching contracts.
 */
function useStreamQueries(template, queryFactory, queryDeps, closeHandler) {
    return ledgerContext.useStreamQueries(template, queryFactory, queryDeps, closeHandler);
}
exports.useStreamQueries = useStreamQueries;
/**
 * React Hook to query the ledger. Same as useStreamQuery, but query by contract key instead.
 *
 * @deprecated prefer useStreamFetchByKeys
 *
 * @typeparam T The contract template type of the query.
 * @typeparam K The contract key type of the query.
 * @typeparam I The template id type.
 *
 * @param template The template of the contracts to match.
 * @param keyFactory A function returning a contract key. Contract
 *        keys must be in "output" format as defined in the [JSON API
 *        docs](https://docs.daml.com/json-api/lf-value-specification.html),
 *        i.e., have to match the types generated by the daml-types library.
 * @param keyDeps The dependencies of the fetch-by-key (for which a change triggers an update of the result).
 * @param closeHandler A callback that will be called if the underlying WebSocket connection fails in an unrecoverable way.
 *
 * @return The matching (unique) contract, or null.
 */
function useStreamFetchByKey(template, keyFactory, keyDeps, closeHandler) {
    return ledgerContext.useStreamFetchByKey(template, keyFactory, keyDeps, closeHandler);
}
exports.useStreamFetchByKey = useStreamFetchByKey;
/**
 * React Hook to query the ledger. Same as useStreamQueries, but query by contract keys instead.
 *
 * @typeparam T The contract template type of the query.
 * @typeparam K The contract key type of the query.
 * @typeparam I The template id type.
 *
 * @param template The template of the contracts to match.
 * @param keyFactory A function returning an array of contract keys. Contract
 *        keys must be in "output" format as defined in the [JSON API
 *        docs](https://docs.daml.com/json-api/lf-value-specification.html),
 *        i.e., have to match the types generated by the daml-types library.
 * @param keyDeps The dependencies of the fetch-by-key (for which a change triggers an update of the result).
 * @param closeHandler A callback that will be called if the underlying WebSocket connection fails in an unrecoverable way.
 *
 * @return An array of the same length as the given array of keys, where each
 *         element is either the currently active contract that matches the
 *         corresponding key, or null if no active contract matches the key in
 *         the same position.
 */
function useStreamFetchByKeys(template, keyFactory, keyDeps, closeHandler) {
    return ledgerContext.useStreamFetchByKeys(template, keyFactory, keyDeps, closeHandler);
}
exports.useStreamFetchByKeys = useStreamFetchByKeys;
/**
 * React Hook to reload all active queries.
 */
function useReload() {
    return ledgerContext.useReload();
}
exports.useReload = useReload;
