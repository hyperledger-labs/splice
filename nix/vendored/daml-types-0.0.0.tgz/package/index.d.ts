import * as jtv from "@mojotech/json-type-validation";
import * as com_daml_ledger_api_v1_value_pb from '@daml/ledger-api/com/daml/ledger/api/v1/value_pb';
/**
 * Interface for companion objects of serializable types. Its main purpose is
 * to serialize and deserialize values between raw JSON and typed values.
 *
 * @typeparam T The template type.
 */
export interface Serializable<T> {
    /**
     * @internal
     */
    decoder: jtv.Decoder<T>;
    /**
     * @internal Encodes T in expected shape for JSON API.
     */
    encode: (t: T) => unknown;
    decodeProto: (v: com_daml_ledger_api_v1_value_pb.Value) => T;
    encodeProto: (t: T) => com_daml_ledger_api_v1_value_pb.Value;
}
/**
 * Companion objects for templates and interfaces, containing their choices.
 *
 * @typeparam T The template payload format or interface view.
 * @typeparam K The contract key type.
 * @typeparam I The template or interface id.
 */
export interface ContractTypeCompanion<T extends object, K, I extends string> {
    templateId: I;
    /**
     * @internal
     */
    sdkVersion: "0.0.0";
    /**
     * @internal
     */
    decoder: jtv.Decoder<T>;
    /**
     * @internal
     */
    keyDecoder: jtv.Decoder<K>;
}
/**
 * Interface for objects representing Daml templates. It is similar to the
 * `Template` type class in Daml.
 *
 * @typeparam T The template type.
 * @typeparam K The contract key type.
 * @typeparam I The template id type.
 *
 */
export interface Template<T extends object, K = unknown, I extends string = string> extends ContractTypeCompanion<T, K, I>, Serializable<T> {
    /**
     * @internal
     */
    keyEncode: (k: K) => unknown;
    keyEncodeProto: (k: K) => com_daml_ledger_api_v1_value_pb.Value;
    Archive: Choice<T, {}, {}, K> & ChoiceFrom<Template<T, K, I>>;
}
/**
 * A mixin for [[Template]] that provides the `toInterface` and
 * `unsafeFromInterface` contract ID conversion functions.
 *
 * Even templates that directly implement no interfaces implement this, because
 * this also permits conversion with interfaces that supply retroactive
 * implementations to this template.
 *
 * @typeparam T The template type.
 * @typeparam IfU The union of implemented interfaces, or `never` for templates
 *            that directly implement no interface.
 */
export interface ToInterface<T extends object, IfU> {
    toInterface<If extends IfU>(ic: FromTemplate<If, unknown>, cid: ContractId<T>): ContractId<If>;
    toInterface<If>(ic: FromTemplate<If, T>, cid: ContractId<T>): ContractId<If>;
    unsafeFromInterface(ic: FromTemplate<IfU, unknown>, cid: ContractId<IfU>): ContractId<T>;
    unsafeFromInterface<If>(ic: FromTemplate<If, T>, cid: ContractId<If>): ContractId<T>;
}
declare const InterfaceBrand: unique symbol;
/**
 * An interface type, for use with contract IDs.
 *
 * @typeparam IfId The interface ID as a constant string.
 */
export declare type Interface<IfId> = {
    readonly [InterfaceBrand]: IfId;
};
/**
 * Interface for objects representing Daml interfaces.
 */
export declare type InterfaceCompanion<T extends object, K, I extends string = string> = ContractTypeCompanion<T, K, I>;
export declare type TemplateOrInterface<T extends object, K = unknown, I extends string = string> = Template<T, K, I> | InterfaceCompanion<T, K, I>;
declare const FromTemplateBrand: unique symbol;
/**
 * A mixin for [[InterfaceCompanion]].  This supplies the basis
 * for the methods of [[ToInterface]].
 *
 * Even interfaces that retroactively implement for no templates implement this,
 * because forward implementations still require this marker to work.
 *
 * @typeparam If The interface type.
 * @typeparam TX The intersection of template types this interface retroactively
 *               implements, or `unknown` if there are none.
 */
export interface FromTemplate<If, TX> {
    readonly [FromTemplateBrand]: [If, TX];
}
/**
 * Interface for objects representing Daml choices.
 *
 * @typeparam T The template type.
 * @typeparam K The contract key type.
 * @typeparam C The choice type.
 * @typeparam R The choice return type.
 *
 */
export interface Choice<T extends object, C, R, K = unknown> extends ChoiceFrom<TemplateOrInterface<T, K>> {
    /**
     * @internal Returns a decoder to decode the choice arguments.
     *
     * Note: we never need to decode the choice arguments, as they are sent over
     * the API but not received.
     */
    argumentDecoder: jtv.Decoder<C>;
    /**
     * @internal
     */
    argumentEncode: (c: C) => unknown;
    argumentSerializable: () => Serializable<C>;
    /**
     * @internal Returns a deocoder to decode the return value.
     */
    resultDecoder: jtv.Decoder<R>;
    resultSerializable: () => Serializable<R>;
    /**
     * The choice name.
     */
    choiceName: string;
}
/**
 * The origin companion that contained a [[Choice]].
 *
 * @typeparam O The type of the template or interface of which
 *            this [[Choice]] is a member.
 */
export interface ChoiceFrom<O> {
    /**
     * Returns the template to which this choice belongs.
     */
    readonly template: () => O;
}
/**
 * @internal
 */
export declare function assembleTemplate<T extends object, TC extends Template<T>, IfU>(template: TC, ..._interfaces: FromTemplate<IfU, unknown>[]): TC & ToInterface<T, IfU>;
/**
 * @internal
 */
export declare function assembleInterface<T extends object, I extends string, C extends object>(templateId: I, decoderSource: () => Serializable<T>, choices: C): InterfaceCompanion<Interface<I> & T, unknown, I> & C;
/**
 * @internal
 */
export declare const registerTemplate: <T extends object>(template: Template<T, unknown, string>) => void;
/**
 * @internal
 */
export declare const lookupTemplate: (templateId: string) => Template<object>;
/**
 * @internal Turn a thunk into a memoized version of itself. The memoized thunk
 * invokes the original thunk only on its first invocation and caches the result
 * for later uses. We use this to implement a version of `jtv.lazy` with
 * memoization.
 */
export declare function memo<A>(thunk: () => A): () => A;
/**
 * @internal Variation of `jtv.lazy` which memoizes the computed decoder on its
 * first invocation.
 */
export declare function lazyMemo<A>(mkDecoder: () => jtv.Decoder<A>): jtv.Decoder<A>;
/**
 * The counterpart of Daml's `()` type.
 */
export interface Unit {
}
/**
 * Companion object of the [[Unit]] type.
 */
export declare const Unit: Serializable<Unit>;
/**
 * The counterpart of Daml's `Bool` type.
 */
export declare type Bool = boolean;
/**
 * Companion object of the [[Bool]] type.
 */
export declare const Bool: Serializable<Bool>;
/**
 * The counterpart of Daml's `Int` type.
 *
 * We represent `Int`s as string in order to avoid a loss of precision.
 */
export declare type Int = string;
/**
 * Companion object of the [[Int]] type.
 */
export declare const Int: Serializable<Int>;
/**
 * The counterpart of Daml's `Numeric` type.
 *
 * We represent `Numeric`s as string in order to avoid a loss of precision. The string must match
 * the regular expression `-?(?:0|[1-9]\d*)(?:\.\d+)?(?:[eE][+-]?\d+)?`.
 */
export declare type Numeric = string;
/**
 * The counterpart of Daml's `Decimal` type.
 *
 * In Daml, Decimal's are the same as Numeric with precision 10.
 *
 */
export declare type Decimal = Numeric;
/**
 * Companion function of the [[Numeric]] type.
 */
export declare const Numeric: (_: number) => Serializable<Numeric>;
/**
 * Companion object of the [[Decimal]] type.
 */
export declare const Decimal: Serializable<Decimal>;
/**
 * The counterpart of Daml's `Text` type.
 */
export declare type Text = string;
/**
 * Companion object of the [[Text]] type.
 */
export declare const Text: Serializable<Text>;
/**
 * The counterpart of Daml's `Time` type.
 *
 * We represent `Times`s as strings with format `YYYY-MM-DDThh:mm:ss[.ssssss]Z`.
 */
export declare type Time = string;
/**
 * Companion object of the [[Time]] type.
 */
export declare const Time: Serializable<Time>;
/**
 * The counterpart of Daml's `Party` type.
 *
 * We represent `Party`s as strings matching the regular expression `[A-Za-z0-9:_\- ]+`.
 */
export declare type Party = string;
/**
 * Companion object of the [[Party]] type.
 */
export declare const Party: Serializable<Party>;
/**
 * The counterpart of Daml's `[T]` list type.
 *
 * We represent lists using arrays.
 *
 * @typeparam T The type of the list values.
 */
export declare type List<T> = T[];
/**
 * Companion object of the [[List]] type.
 */
export declare const List: <T>(t: Serializable<T>) => Serializable<T[]>;
/**
 * The counterpart of Daml's `Date` type.
 *
 * We represent `Date`s as strings with format `YYYY-MM-DD`.
 */
export declare type Date = string;
/**
 * Companion object of the [[Date]] type.
 */
export declare const Date: Serializable<Date>;
/**
 * Used to `brand` [[ContractId]].
 */
declare const ContractIdBrand: unique symbol;
/**
 * The counterpart of Daml's `ContractId T` type.
 *
 * We represent `ContractId`s as strings. Their exact format of these strings depends on the ledger
 * the Daml application is running on.
 *
 * The purpose of the intersection with `{ [ContractIdBrand]: T }` is to
 * prevent accidental use of a `ContractId<T>` when a `ContractId<U>` is
 * needed (unless `T` is a subtype of `U`). This technique is known as
 * "branding" in the TypeScript community.
 *
 * @typeparam T The contract template.
 */
export declare type ContractId<T> = string & {
    [ContractIdBrand]: T;
};
/**
 * Companion object of the [[ContractId]] type.
 */
export declare const ContractId: <T>(_t: Serializable<T> | TemplateOrInterface<T & object, unknown, string>) => Serializable<ContractId<T>>;
/**
 * The counterpart of Daml's `Optional T` type.
 *
 * @typeparam T The type of the optionally present value.
 */
export declare type Optional<T> = null | OptionalInner<T>;
/**
 * Inner type of [[Optional]].
 */
declare type OptionalInner<T> = null extends T ? [] | [Exclude<T, null>] : T;
/**
 * Companion function of the [[Optional]] type.
 */
export declare const Optional: <T>(t: Serializable<T>) => Serializable<Optional<T>>;
/**
 * The counterpart of Daml's `TextMap T` type.
 *
 * We represent `TextMap`s as dictionaries.
 *
 * @typeparam T The type of the map values.
 */
export declare type TextMap<T> = {
    [key: string]: T;
};
/**
 * Companion object of the [[TextMap]] type.
 */
export declare const TextMap: <T>(t: Serializable<T>) => Serializable<TextMap<T>>;
/**
 * The counterpart of Daml's `DA.Map.Map K V` type.
 *
 * This is an immutable map which compares keys via deep equality. The order of
 * iteration is unspecified; the only guarantee is that the order in `keys` and
 * `values` match, i.e. `m.get(k)` is (deep-, value-based) equal to
 * `[...m.values()][[...m.keys()].findIndex((l) => _.isEqual(k, l))]`
 *
 * @typeparam K The type of the map keys.
 * @typeparam V The type of the map values.
 */
export interface Map<K, V> {
    get: (k: K) => V | undefined;
    has: (k: K) => boolean;
    set: (k: K, v: V) => Map<K, V>;
    delete: (k: K) => Map<K, V>;
    keys: () => Iterator<K, undefined, undefined>;
    values: () => Iterator<V, undefined, undefined>;
    entries: () => Iterator<[K, V], undefined, undefined>;
    entriesArray: () => [K, V][];
    forEach: <T, U>(f: (value: V, key: K, map: Map<K, V>) => T, u?: U) => void;
}
export declare const emptyMap: <K, V>() => Map<K, V>;
/**
 * Companion function of the [[GenMap]] type.
 */
export declare const Map: <K, V>(kd: Serializable<K>, vd: Serializable<V>) => Serializable<Map<K, V>>;
export {};
