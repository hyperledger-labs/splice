"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
// Copyright (c) 2023 Digital Asset (Switzerland) GmbH and/or its affiliates. All rights reserved.
// SPDX-License-Identifier: Apache-2.0
var index_1 = require("./index");
var lodash_1 = __importDefault(require("lodash"));
function makeArr(it) {
    var r = [];
    var i = it.next();
    while (!i.done) {
        r.push(i.value);
        i = it.next();
    }
    return r;
}
describe("@daml/types", function () {
    it("optional", function () {
        var dict = (0, index_1.Optional)(index_1.Text);
        expect(dict.decoder.run(null).ok).toBe(true);
        expect(dict.decoder.run("X").ok).toBe(true);
        expect(dict.decoder.run([]).ok).toBe(false);
        expect(dict.decoder.run(["X"]).ok).toBe(false);
    });
    it("nested optionals", function () {
        var dict = (0, index_1.Optional)((0, index_1.Optional)(index_1.Text));
        expect(dict.decoder.run(null).ok).toBe(true);
        expect(dict.decoder.run([]).ok).toBe(true);
        expect(dict.decoder.run(["X"]).ok).toBe(true);
        expect(dict.decoder.run("X").ok).toBe(false);
        expect(dict.decoder.run([["X"]]).ok).toBe(false);
        expect(dict.decoder.run([[]]).ok).toBe(false);
        expect(dict.decoder.run([null]).ok).toBe(false);
    });
    it("genmap", function () {
        var _a = (0, index_1.Map)(index_1.Text, index_1.Text), encode = _a.encode, decoder = _a.decoder;
        var decode = function (u) { return decoder.runWithException(u); };
        var kvs = [
            ["1", "a"],
            ["2", "b"],
        ];
        expect(encode(decode(kvs))).toEqual(kvs);
        var m = decode(kvs);
        expect(m.get("1")).toEqual("a");
        expect(m.get("3")).toEqual(undefined);
        expect(m.has("1")).toBe(true);
        expect(m.has("a")).toBe(false);
        expect(m.set("3", "c").get("3")).toEqual("c");
        expect(m.delete("1").get("1") || "not found").toEqual("not found");
        expect(m.get("1")).toEqual("a");
        expect(makeArr(m.keys())).toEqual(["1", "2"]);
        expect(makeArr(m.values())).toEqual(["a", "b"]);
        expect(makeArr(m.entries())).toEqual(kvs);
        expect(m.entriesArray()).toEqual(kvs);
        var counter = (function () {
            var i = 0;
            return function () {
                i = i + 1;
                return i;
            };
        })();
        var m2 = (0, index_1.emptyMap)()
            .set("a", "b")
            .set("c", "d")
            .set("e", "f");
        var res1 = [];
        m2.forEach(function (v, k, m) {
            res1.push([v, k, m, this()]);
        }, counter);
        var res2 = [];
        m2.forEach(function (v, k, m) {
            res2.push([v, k, m]);
        });
        expect(res1).toEqual([
            ["b", "a", m2, 1],
            ["d", "c", m2, 2],
            ["f", "e", m2, 3],
        ]);
        expect(res2).toEqual([
            ["b", "a", m2],
            ["d", "c", m2],
            ["f", "e", (0, index_1.emptyMap)().set("e", "f").set("a", "b").set("c", "d")],
        ]);
        var _loop_1 = function (k) {
            expect(m2.get(k)).toEqual(makeArr(m2.values())[makeArr(m2.keys()).findIndex(function (l) { return lodash_1.default.isEqual(k, l); })]);
        };
        for (var _i = 0, _b = ["a", "c", "e", "not found"]; _i < _b.length; _i++) {
            var k = _b[_i];
            _loop_1(k);
        }
    });
    it("nested genmap", function () {
        var _a = (0, index_1.Map)(index_1.Text, (0, index_1.Map)(index_1.Text, index_1.Text)), encode = _a.encode, decoder = _a.decoder;
        var decoded = (0, index_1.emptyMap)().set("a", (0, index_1.emptyMap)().set("b", "c"));
        var decode = function (u) {
            return decoder.runWithException(u);
        };
        var encoded = [["a", [["b", "c"]]]];
        expect(encode(decoded)).toEqual(encoded);
        expect(decode(encoded)).toEqual(decoded);
    });
});
test("memo", function () {
    var x = 0;
    var f = (0, index_1.memo)(function () {
        x += 1;
        return x;
    });
    expect(f()).toBe(1);
    expect(f()).toBe(1);
    expect(x).toBe(1);
});
//# sourceMappingURL=index.test.js.map